"""
HARI 7: MINI PROJECT - Kalkulator BMI (Body Mass Index)
Tujuan: Menggabungkan semua yang dipelajari di Minggu 1
"""

print("="*50)
print("    KALKULATOR BMI (Body Mass Index)")
print("="*50)

# Input dari user
nama = input("\nNama: ")
berat = float(input("Berat badan (kg): "))
tinggi = float(input("Tinggi badan (meter): "))

# Hitung BMI
bmi = berat / (tinggi ** 2)

# Tentukan kategori
if bmi < 18.5:
    kategori = "Kekurangan Berat Badan"
    saran = "Anda perlu menambah berat badan. Konsultasi dengan ahli gizi."
elif bmi < 25:
    kategori = "Normal"
    saran = "Pertahankan pola hidup sehat Anda!"
elif bmi < 30:
    kategori = "Kelebihan Berat Badan"
    saran = "Mulai olahraga teratur dan atur pola makan."
else:
    kategori = "Obesitas"
    saran = "Segera konsultasi dengan dokter untuk program penurunan berat badan."

# Tampilkan hasil
print("\n" + "="*50)
print("           HASIL PERHITUNGAN BMI")
print("="*50)
print(f"Nama        : {nama}")
print(f"Berat       : {berat} kg")
print(f"Tinggi      : {tinggi} m")
print(f"BMI         : {bmi:.2f}")
print(f"Kategori    : {kategori}")
print(f"Saran       : {saran}")
print("="*50)

# Referensi kategori BMI
print("\n📊 REFERENSI KATEGORI BMI:")
print("  < 18.5     : Kekurangan Berat Badan")
print("  18.5 - 24.9: Normal")
print("  25.0 - 29.9: Kelebihan Berat Badan")
print("  ≥ 30.0     : Obesitas")

print("\n✅ Mini Project Minggu 1 Selesai!")
print("🎉 Selamat! Anda sudah menguasai fundamental Python!")
print("📚 Siap lanjut ke Minggu 2: Loops & Collections?")
