"""
HARI 1: Hello World & Setup
Tujuan: Mengenal Python dan membuat program pertama
"""

# Program pertama - Hello World!
print("Hello, World!")

# Print dengan berbagai format
print("="*50)
print("Selamat datang di Python!")
print("="*50)

# Multiple print statements
print("Nama saya adalah pemula Python")
print("Saya sedang belajar programming")
print("Python adalah bahasa yang mudah dipelajari")

# Print dengan karakter khusus
print("\n")  # Baris baru
print("Python\tadalah\tmudah")  # Tab
print("Baris 1\nBaris 2\nBaris 3")  # Multiple lines

# ============================================
# LATIHAN HARI 1
# ============================================
# Uncomment dan lengkapi kode di bawah ini:

# LATIHAN 1.1: Tampilkan nama dan umur Anda
# print("Nama saya: [ISI NAMA ANDA]")
# print("Umur saya: [ISI UMUR ANDA] tahun")

# LATIHAN 1.2: Print 5 hobi Anda
# print("Hobi 1: ")
# print("Hobi 2: ")
# print("Hobi 3: ")
# print("Hobi 4: ")
# print("Hobi 5: ")

print("\n✅ Selamat! Anda telah menyelesaikan Hari 1!")
