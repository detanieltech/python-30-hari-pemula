"""
HARI 2: Variabel dan Tipe Data
Tujuan: Memahami cara menyimpan data dalam variabel
"""

# Variabel dengan tipe data berbeda
nama = "Budi"
umur = 25
tinggi = 170.5
is_student = True

print("=== INFORMASI PERSONAL ===")
print(f"Nama: {nama}")
print(f"Umur: {umur} tahun")
print(f"Tinggi: {tinggi} cm")
print(f"Status Mahasiswa: {is_student}")

# Mengecek tipe data
print("\n=== TIPE DATA ===")
print(f"Tipe 'nama': {type(nama)}")
print(f"Tipe 'umur': {type(umur)}")
print(f"Tipe 'tinggi': {type(tinggi)}")
print(f"Tipe 'is_student': {type(is_student)}")

# Konversi tipe data
angka_string = "100"
angka_int = int(angka_string)
print(f"\nKonversi '{angka_string}' (string) ke {angka_int} (integer)")

# Multiple assignment
x, y, z = 10, 20, 30
print(f"\nMultiple assignment: x={x}, y={y}, z={z}")

# Variabel dengan nama yang baik dan buruk
good_variable_name = "Good"  # ✅ Baik: snake_case, deskriptif
# 1variable = "Bad"  # ❌ Error: tidak boleh dimulai dengan angka
# my-variable = "Bad"  # ❌ Error: tidak boleh pakai dash

# ============================================
# LATIHAN HARI 2
# ============================================
print("\n=== LATIHAN ===")

# LATIHAN 2.1: Buat variabel untuk data diri Anda
# nama_saya = 
# kota_saya = 
# umur_saya = 
# berat_badan = 
# hobi = 
# print(nama_saya, kota_saya, umur_saya, berat_badan, hobi)

# LATIHAN 2.2: Tukar nilai dua variabel
a = 5
b = 10
print(f"Sebelum tukar: a={a}, b={b}")
# Tulis kode untuk tukar nilai a dan b di sini:
# HINT: Gunakan teknik multiple assignment
# a, b = b, a
# print(f"Setelah tukar: a={a}, b={b}")

print("\n✅ Selesai! Lanjut ke Hari 3")
